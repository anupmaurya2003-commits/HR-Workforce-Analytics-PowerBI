---
name: Executive Workforce Intelligence
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464555'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#950029'
  on-tertiary: '#ffffff'
  tertiary-container: '#c20038'
  on-tertiary-container: '#ffd0d2'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#ffdada'
  tertiary-fixed-dim: '#ffb3b6'
  on-tertiary-fixed: '#40000c'
  on-tertiary-fixed-variant: '#920028'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Outfit
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Outfit
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Outfit
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  display-kpi:
    fontFamily: Outfit
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.03em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
  code-num:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-compact: 0.75rem
  margin: 1.5rem
  margin-compact: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.25rem
  space-xl: 1.75rem
---

## Brand & Style

This design system targets People Analytics leaders, CHROs, and HR Business Partners requiring decisive, enterprise-grade clarity across complex human capital data. The aesthetic merges precision engineering with executive boardroom composure. It avoids playful or consumer-grade ornamentation in favor of dense, legible data layouts, structured visual hierarchies, and high-trust analytical rigor.

The design movement is **Corporate / Modern** optimized for dense business intelligence surfaces:
- Canvas structure is architectural and deliberate, using high-contrast deep slate framing (`#0F172A`, `#1E293B`) against an ultra-crisp, light analytical background (`#F8FAFC`).
- Polished, micro-bordered card containers isolate visual metrics without visual noise.
- Every pixel of real estate serves cognitive velocity: immediate comprehension of workforce headcount, flight risks, hiring velocity, and compensation equity.

## Colors

The palette establishes strict semantic accountability tailored specifically for HR talent lifecycle metrics:

- **Structural Canvas & Navigation**:
  - Global Nav / Executive Banner: Slate 900 (`#0F172A`) paired with Slate 800 (`#1E293B`) for sub-navigation and active section headers.
  - Workspace Background: Crisp off-white slate (`#F8FAFC`).
  - Card & Container Fill: Pure white (`#FFFFFF`).
  - Structural Borders & Grid Lines: Neutral slate line (`#E2E8F0`), with subtle inner divider lines at (`#F1F5F9`).

- **Core Data & Identity**:
  - Primary (`#4F46E5`): Corporate Indigo for standard analytical marks, primary metric aggregations, interactive filters, and focal KPIs.
  - Secondary (`#0D9488`): Deep Teal for secondary cohorts, talent acquisition funnels, and benchmark overlays.

- **Workforce Diagnostics & Status Semantics**:
  - Retention / Positive Growth: Emerald (`#10B981`) for headcount gains, retention rates, and top performance tiers.
  - Attrition / High Risk: Rose (`#E11D48`) reserved strictly for voluntary/involuntary exits, critical flight risks, and compliance shortfalls.
  - Caution / Pending Pipeline: Amber (`#F59E0B`) for tenure milestones approaching cliff dates, requisitions exceeding SLA, and compensation drift.
  - Informational / Benchmarks: Sky Blue (`#0284C7`) for industry comparisons and external market rates.

## Typography

The type system blends the geometric confidence of `Outfit` for executive titles and high-impact KPI totals with the tabular precision of `Inter` for dense data grids, chart labels, and interface chrome.

- **KPI Callouts**: Utilize `display-kpi` with tabular figures enabled (`font-variant-numeric: tabular-nums`) to ensure vertical alignment across dynamic dashboard updates.
- **Micro Labels**: `label-sm` utilizes uppercase casing with letter spacing for axis titles, slicer category headers, and column groupings.
- **Numbers & Metrics**: All numerical tables and data list rows must enforce tabular figures to preserve vertical column scanning.

## Layout & Spacing

The canvas is engineered around a 12-column grid system optimized for 16:9 and 16:10 executive workstation displays.

- **Dashboard Anatomy**:
  - Top Navigation Bar: Fixed height of 56px (`#0F172A`), providing organization breadcrumbs, global time horizon toggles, and report export actions.
  - Slicer / Filter Rail: Collapsible lateral panel (260px desktop width) positioned on the right or left edge with an internal padding of `space-md`.
  - Analytical Canvas: Fluid multi-row grid utilizing `gutter` (16px) gaps between KPI cards, chart tiles, and tabular breakdown containers.
- **Component Padding**:
  - Tiles and visual containers use strict internal padding of `space-md` (16px) for standard charts and `space-lg` (20px) for premier KPI hero blocks.
  - Dense grid rows and slicer dropdown items use `space-sm` (8px) vertical padding to maximize visible row density without sacrificing pointer target accuracy.

## Elevation & Depth

Visual hierarchy relies on low-contrast structural containment rather than heavy drop shadows, mimicking the clean aesthetic of native enterprise business intelligence tools:

- **Base Ground (Level 0)**: The analytical canvas `#F8FAFC`.
- **Card Surfaces (Level 1)**: Pure white `#FFFFFF` tiles bounded by a razor-thin 1px border of `#E2E8F0`. Shadows are subtle and diffuse: `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.03)`.
- **Active Card Hover / Visual Focus (Level 2)**: Maintained at 1px border transitioning to `#CBD5E1`, with shadow elevation `0 4px 6px -1px rgba(15, 23, 42, 0.06), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.
- **Flyouts, Slicer Dropdowns & Context Panels (Level 3)**: `#FFFFFF` surface with an explicit 1px `#CBD5E1` border and elevated shadow `0 10px 15px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -4px rgba(15, 23, 42, 0.03)`.
- **Visual Headers**: Individual chart containers feature a distinct top-docked action bar (`#FFFFFF` with a bottom divider line of `#F1F5F9`) holding title, drill-down icons, spotlight toggle, and export buttons.

## Shapes

The design system implements a refined, low-radius geometry (`1` - Soft). This keeps data panels crisp and structural, avoiding casual toy-like aesthetics while mitigating the harshness of 0px corners.

- **Tiles & Containers**: `4px` (`rounded-sm`) to `8px` (`rounded-lg`) border-radius.
- **Interactive Controls & Inputs**: Form fields, slicer dropdowns, search bars, and segmented tab pills use `4px` (`rounded-sm`) corners.
- **Status Badges & Category Chips**: Micro-chips maintain a tight `4px` corner; pill radials are reserved exclusively for compact numeric counter bubbles within slicer rows.

## Components

### 1. KPI Metric Cards
- **Composition**: Dedicated card container featuring:
  - Header: Micro-label (`label-sm`) in `#64748B`, tracking uppercase.
  - Main Metric: Tabular numeric display (`display-kpi`) in `#0F172A`.
  - Trend Indicator: Pill badge displaying Delta percentage (`label-sm`). Positive gains (Emerald `#10B981` text over `#ECFDF5` background), negative/attrition metrics (Rose `#E11D48` over `#FFF1F2`).
  - Micro-Visualization: Embedded sparkline or mini target bar nestled in the lower 24px of the tile.

### 2. Power BI Visual Container & Chart Headers
- **Visual Header**: Subtle hover-state utility bar containing icons for drill up, drill down, next level hierarchy, expand all, focus mode, and ellipsis options.
- **Title Block**: `headline-sm` in `#1E293B` left-aligned, followed by a secondary subtitle (`label-sm` in `#64748B`) summarizing active filter context.
- **Chart Body**: Integrated zero-margin margin canvas with high-contrast axis tick lines (`#CBD5E1`) and dashed reference guidelines (`#E2E8F0`).

### 3. Slicers & Filter Controls
- **Dropdown Slicers**: White input surface with 1px `#CBD5E1` border, Chevron-down glyph, and selected pill counter tags in `#EEF2FF` with `#4F46E5` text.
- **Tile / Hierarchy Slicers**: Segmented button lists with light-slate default states (`#F1F5F9`) flipping to Slate 900 (`#0F172A`) with white text upon selection.
- **Search & Clear**: Embedded micro search input with clear-all icon button (`#94A3B8`).

### 4. Interactive Tabs & Page Navigation
- Horizontal tab strip resting underneath the main executive header.
- Inactive state: `#64748B` typography, transparent background.
- Active state: `#4F46E5` primary text with a persistent bottom border indicator (2px height, `#4F46E5`), accompanied by a soft background tint (`rgba(79, 70, 229, 0.04)`).

### 5. Data Tables with In-Cell Sparklines & Indicators
- **Header**: `#F8FAFC` background with a solid 1px `#E2E8F0` bottom edge; text styled in `label-sm` with active sort glyphs.
- **Row Architecture**: Alternating hover fill (`#F8FAFC`), base fill `#FFFFFF`, 36px compact row height.
- **In-Cell Graphics**: 16px height horizontal bullet charts showing target realization and in-line SVG sparklines rendering 12-month rolling turnover trends.

### 6. Buttons & Interactive Controls
- **Primary Action**: Solid Corporate Indigo (`#4F46E5`), hover `#4338CA`, active `#3730A3`, text `#FFFFFF`.
- **Secondary / Utility**: Surface `#FFFFFF`, border 1px `#CBD5E1`, text `#334155`, hover background `#F8FAFC`.
- **Destructive Filter / Reset**: Ghost button, Rose `#E11D48` hover tint with `#94A3B8` default.